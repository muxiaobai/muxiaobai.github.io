---
title: 404 Not Found：该页无法显示
date: 2016-06-20 13:06:56
tags: 404
permalink: /404
---
<style type="text/css">
    .article-header {
        padding: 0;
        padding-top: 26px;
        border-left: none;
        text-align: center;
    }
    .article-header:hover {
        border-left: none;
    }
    .article-title {
        font-size: 2.1em;
    }
    strong a {
        color: #747474;
    }
    .article-meta {
        display: none;
    }
    .share {
        display: none;
    }
    .ds-meta {
        display: none;
    }
    .player {
        margin-left: -10px;
    }
    .sign {
        text-align: right;
        font-style: italic;
    }
    #page-visit {
        display: none;
    }
    .center {
        text-align: center;
        height: 2.5em;
        font-weight: bold;
    }
    .article-entry hr {
        margin: 0;
    }
    .pic {
        text-align: center;
        margin: 0;
    }
    .pic br {
        display: none;
    }
    #container .article-info-post.article-info {
    display: none;
    }
    #container .article .article-title {
    padding: 0;
    }
</style>
